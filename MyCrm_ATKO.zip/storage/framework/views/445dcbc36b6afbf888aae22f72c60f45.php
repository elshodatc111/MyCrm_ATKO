
<?php $__env->startSection('title','Online Kurslar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Online Kurslar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Online Kurslar</li>
        </ol>
    </nav>
</div> 
    <section class="section dashboard">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <h1 class="card-title">Online kurslar</h1>
                <div class="table-responsive">
                    <table class="table table-bordered text-center" style="font-size:14px">
                    <thead>
                        <tr>
                            <td class="bg-primary text-white">#</td>
                            <td class="bg-primary text-white">Filial kurs</td>
                            <td class="bg-primary text-white">Online kurs</td>
                            <td class="bg-primary text-white">Status</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($value['cours_name']); ?></td>
                            <td><?php echo e($value['cours_name_api']); ?></td>
                            <td>
                                <a href="<?php echo e(route('online_update',$value['id'])); ?>">
                                    <i class="bi bi-gear"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyCrm_ATKO\resources\views/SuperAdmin/online/index.blade.php ENDPATH**/ ?>