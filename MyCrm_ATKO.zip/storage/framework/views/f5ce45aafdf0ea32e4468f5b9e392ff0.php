<?php $__env->startSection('title',"To'lovlar"); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>To'lovlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('User')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">To'lovlar</li>
            </ol>
        </nav>
    </div>


    <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title w-100 text-center pb-0">To'lov qilish</h5>
                    <form action="<?php echo e(route('TolovPost')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="number" name="summa" class="form-control mb-1 " required>
                        <button class="btn btn-primary w-100 w-100 mt-1">To'lov</button>
                    </form>
                </div>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $Tulov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title w-100 text-center"><?php echo e($item['summa']); ?></h5>
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">To'lov turi:</h6><small><?php echo e($item['type']); ?></small>
                    </div>
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">To'lov vaqti:</h6><small><?php echo e($item['created_at']); ?></small>
                    </div>
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">To'lov holati:</h6><small class="text-success">Tasdiqlandi</small>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>
    </div>
    
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyCrm_ATKO\resources\views/User/tulovlar.blade.php ENDPATH**/ ?>