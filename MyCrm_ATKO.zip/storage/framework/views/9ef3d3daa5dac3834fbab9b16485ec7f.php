<?php $__env->startSection('title','Statistika'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Statistika</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('filial')); ?>">Filiallar</a></li>
            <li class="breadcrumb-item active">Oylik Statistika</li>
        </ol>
    </nav>
</div> 
    <section class="section dashboard">
        <div class="card">
            <div class="card-body">
                <div class="row pt-2">
                    <div class="col-6 bg-primary"><a href="<?php echo e(route('SuperAdminStatistika',$filial_id)); ?>"><h5 class="card-title w-100 text-center  text-white">Oylik Statistika</h5></a></div>
                    <div class="col-6"><a href="<?php echo e(route('statistikaKun',$filial_id)); ?>"><h5 class="card-title w-100 text-center text-primary">Kunlik Statistika</h5></a></div>
                </div><hr class="p-0 m-0">
                <div class="row">
                    <div class="col-lg-6">
                        <h1 class="card-title">Oylik tashriflar</h1>
                        <canvas id="kunlik_tashrif" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                                new Chart(document.querySelector('#kunlik_tashrif'), {
                                type: 'radar',
                                data: {
                                    labels: [
                                        "<?php echo e($Tashriflar[0]['month']); ?>",
                                        "<?php echo e($Tashriflar[1]['month']); ?>",
                                        "<?php echo e($Tashriflar[2]['month']); ?>",
                                        "<?php echo e($Tashriflar[3]['month']); ?>",
                                        "<?php echo e($Tashriflar[4]['month']); ?>",
                                        "<?php echo e($Tashriflar[5]['month']); ?>",
                                        "<?php echo e($Tashriflar[6]['month']); ?>"
                                    ],
                                    datasets: [{
                                    label: '',
                                    data: [
                                        <?php echo e($Tashriflar[0]['tashriflar']); ?>,
                                        <?php echo e($Tashriflar[1]['tashriflar']); ?>,
                                        <?php echo e($Tashriflar[2]['tashriflar']); ?>,
                                        <?php echo e($Tashriflar[3]['tashriflar']); ?>,
                                        <?php echo e($Tashriflar[4]['tashriflar']); ?>,
                                        <?php echo e($Tashriflar[5]['tashriflar']); ?>,
                                        <?php echo e($Tashriflar[6]['tashriflar']); ?>,
                                    ],
                                    fill: true,
                                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                    borderColor: 'rgb(54, 162, 235)',
                                    pointBackgroundColor: 'rgb(54, 162, 235)',
                                    pointBorderColor: '#fff',
                                    pointHoverBackgroundColor: '#fff',
                                    pointHoverBorderColor: 'rgb(54, 162, 235)'
                                    }]
                                },
                                options: {elements: {line: {borderWidth: 3}}}
                                });
                            });
                        </script>
                    </div>
                    <div class="col-lg-6">
                        <h1 class="card-title">Tashriflar(oxirgi 45 kun)</h1>
                        <canvas id="crm_tashrif" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                                new Chart(document.querySelector('#crm_tashrif'), {
                                    type: 'radar',
                                    data: {
                                        labels: ['Telegram','Instagram','Facebook','Bannerlar','Tanishlar','Boshqa'],
                                        datasets: [{
                                            label: '',
                                            data: [
                                                    <?php echo e($Tashriflar['telegram']); ?>,
                                                    <?php echo e($Tashriflar['instagram']); ?>,
                                                    <?php echo e($Tashriflar['facebook']); ?>,
                                                    <?php echo e($Tashriflar['banner']); ?>,
                                                    <?php echo e($Tashriflar['tanishlar']); ?>,
                                                    <?php echo e($Tashriflar['boshqalar']); ?>,
                                                ],
                                            fill: true,
                                            backgroundColor: 'rgba(255, 65, 65, 0.4)',
                                            borderColor: 'rgb(52, 205, 244)',
                                            pointBackgroundColor: 'rgb(54, 205, 244)',
                                            pointBorderColor: '#fff',
                                            pointHoverBackgroundColor: '#fff',
                                            pointHoverBorderColor: 'rgb(54, 205, 235)'
                                        }]
                                    },
                                    options: {elements: {line: {borderWidth: 3}}}
                                });
                            });
                        </script>
                    </div>
                    <div class="col-lg-12"><hr></div>
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Activ Talabalar</h5>
                                <div id="lineChart"></div>
                                <script>
                                    document.addEventListener("DOMContentLoaded", () => {
                                        new ApexCharts(document.querySelector("#lineChart"), {
                                            series: [{name: "Activ tashriflar",
                                                data: [
                                                    <?php echo e($Active[0]['count']); ?>,
                                                    <?php echo e($Active[1]['count']); ?>,
                                                    <?php echo e($Active[2]['count']); ?>,
                                                    <?php echo e($Active[3]['count']); ?>,
                                                    <?php echo e($Active[4]['count']); ?>,
                                                    <?php echo e($Active[5]['count']); ?>,
                                                    <?php echo e($Active[6]['count']); ?>,
                                                ]
                                            }],
                                            chart: {height: 350,type: 'line',zoom: {enabled: false}},
                                            dataLabels: {enabled: false},
                                            stroke: {curve: 'straight'},
                                            grid: {row: {colors: ['#f3f3f3', 'transparent'],opacity: 0.5},},
                                            xaxis: {categories: 
                                                [
                                                    "<?php echo e($Active[0]['data']); ?>",
                                                    "<?php echo e($Active[1]['data']); ?>",
                                                    "<?php echo e($Active[2]['data']); ?>",
                                                    "<?php echo e($Active[3]['data']); ?>",
                                                    "<?php echo e($Active[4]['data']); ?>",
                                                    "<?php echo e($Active[5]['data']); ?>",
                                                    "<?php echo e($Active[6]['data']); ?>",
                                                ]
                                            ,}
                                        }).render();
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body pt-3 mb-3">
                                <canvas id="statistika" style="max-height: 400px;"></canvas>
                                <script>
                                    document.addEventListener("DOMContentLoaded", () => {
                                        new Chart(document.querySelector('#statistika'), {
                                            type: 'radar',
                                            data: {
                                                labels: [
                                                    "<?php echo e($Yillik[1]['date']); ?>",
                                                    "<?php echo e($Yillik[2]['date']); ?>",
                                                    "<?php echo e($Yillik[3]['date']); ?>",
                                                    "<?php echo e($Yillik[4]['date']); ?>",
                                                    "<?php echo e($Yillik[5]['date']); ?>",
                                                    "<?php echo e($Yillik[6]['date']); ?>",
                                                    "<?php echo e($Yillik[7]['date']); ?>",
                                                    "<?php echo e($Yillik[8]['date']); ?>",
                                                    "<?php echo e($Yillik[9]['date']); ?>",
                                                    "<?php echo e($Yillik[10]['date']); ?>",
                                                    "<?php echo e($Yillik[11]['date']); ?>",
                                                    "<?php echo e($Yillik[12]['date']); ?>"
                                                ],
                                                datasets: [{
                                                    label: "To'lovlar",
                                                    data: [
                                                        <?php echo e($Yillik[1]['Tulov']); ?>,
                                                        <?php echo e($Yillik[2]['Tulov']); ?>,
                                                        <?php echo e($Yillik[3]['Tulov']); ?>,
                                                        <?php echo e($Yillik[4]['Tulov']); ?>,
                                                        <?php echo e($Yillik[5]['Tulov']); ?>,
                                                        <?php echo e($Yillik[6]['Tulov']); ?>,
                                                        <?php echo e($Yillik[7]['Tulov']); ?>,
                                                        <?php echo e($Yillik[8]['Tulov']); ?>,
                                                        <?php echo e($Yillik[9]['Tulov']); ?>,
                                                        <?php echo e($Yillik[10]['Tulov']); ?>,
                                                        <?php echo e($Yillik[11]['Tulov']); ?>,
                                                        <?php echo e($Yillik[12]['Tulov']); ?>,
                                                    ],
                                                    fill: true,
                                                    backgroundColor: 'rgba(255, 65, 65, 0.4)',
                                                    borderColor: 'green',
                                                    pointBackgroundColor: 'rgb(54, 205, 244)',
                                                    pointBorderColor: '#fff',
                                                    pointHoverBackgroundColor: '#fff',
                                                    pointHoverBorderColor: 'rgb(54, 205, 235)'
                                                },{
                                                    label: "Xarajatlar + Ish haqi",
                                                    data: [
                                                        <?php echo e($Yillik[1]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[2]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[3]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[4]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[5]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[6]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[7]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[8]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[9]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[10]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[11]['Xarajat']); ?>,
                                                        <?php echo e($Yillik[12]['Xarajat']); ?>,
                                                    ],
                                                    fill: true,
                                                    backgroundColor: 'rgba(255, 255, 65, 0.4)',
                                                    borderColor: 'blue',
                                                    pointBackgroundColor: 'rgb(54, 205, 244)',
                                                    pointBorderColor: '#fff',
                                                    pointHoverBackgroundColor: '#fff',
                                                    pointHoverBorderColor: 'rgb(54, 205, 235)'
                                                }]
                                            },
                                            options: {elements: {line: {borderWidth: 3}}}
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <h1 class="card-title">Oylik to'lovlar</h1>
                        <div id="columnChart"></div>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                                new ApexCharts(document.querySelector("#columnChart"), {
                                    series: [{
                                        name: "Naqt to'lovlar",
                                        data: [
                                            <?php echo e($OylikTulovAll[0]['Naqt']); ?>,
                                            <?php echo e($OylikTulovAll[1]['Naqt']); ?>,
                                            <?php echo e($OylikTulovAll[2]['Naqt']); ?>,
                                            <?php echo e($OylikTulovAll[3]['Naqt']); ?>,
                                            <?php echo e($OylikTulovAll[4]['Naqt']); ?>,
                                            <?php echo e($OylikTulovAll[5]['Naqt']); ?>,
                                            <?php echo e($OylikTulovAll[6]['Naqt']); ?>

                                        ]
                                    }, {
                                        name: "Plastik to'lovlar",
                                        data: [
                                            <?php echo e($OylikTulovAll[0]['Plastik']); ?>,
                                            <?php echo e($OylikTulovAll[1]['Plastik']); ?>,
                                            <?php echo e($OylikTulovAll[2]['Plastik']); ?>,
                                            <?php echo e($OylikTulovAll[3]['Plastik']); ?>,
                                            <?php echo e($OylikTulovAll[4]['Plastik']); ?>,
                                            <?php echo e($OylikTulovAll[5]['Plastik']); ?>,
                                            <?php echo e($OylikTulovAll[6]['Plastik']); ?>

                                        ]
                                    }, {
                                        name: "Payme to'lov",
                                        data: [
                                            <?php echo e($OylikTulovAll[0]['Payme']); ?>,
                                            <?php echo e($OylikTulovAll[1]['Payme']); ?>,
                                            <?php echo e($OylikTulovAll[2]['Payme']); ?>,
                                            <?php echo e($OylikTulovAll[3]['Payme']); ?>,
                                            <?php echo e($OylikTulovAll[4]['Payme']); ?>,
                                            <?php echo e($OylikTulovAll[5]['Payme']); ?>,
                                            <?php echo e($OylikTulovAll[6]['Payme']); ?>

                                        ]
                                    }, {
                                        name: "Qaytarilgan to'lovlar",
                                        data: [
                                            <?php echo e($OylikTulovAll[0]['Qaytar']); ?>,
                                            <?php echo e($OylikTulovAll[1]['Qaytar']); ?>,
                                            <?php echo e($OylikTulovAll[2]['Qaytar']); ?>,
                                            <?php echo e($OylikTulovAll[3]['Qaytar']); ?>,
                                            <?php echo e($OylikTulovAll[4]['Qaytar']); ?>,
                                            <?php echo e($OylikTulovAll[5]['Qaytar']); ?>,
                                            <?php echo e($OylikTulovAll[6]['Qaytar']); ?>

                                        ]
                                    }, {
                                        name: "Chegirmalar",
                                        data: [
                                            <?php echo e($OylikTulovAll[0]['Chegirma']); ?>,
                                            <?php echo e($OylikTulovAll[1]['Chegirma']); ?>,
                                            <?php echo e($OylikTulovAll[2]['Chegirma']); ?>,
                                            <?php echo e($OylikTulovAll[3]['Chegirma']); ?>,
                                            <?php echo e($OylikTulovAll[4]['Chegirma']); ?>,
                                            <?php echo e($OylikTulovAll[5]['Chegirma']); ?>,
                                            <?php echo e($OylikTulovAll[6]['Chegirma']); ?>

                                        ]
                                    }],
                                    chart: {type: 'bar',height: 350},
                                    plotOptions: {
                                        bar: {horizontal: false,columnWidth: '55%',endingShape: 'rounded'},
                                    },
                                    dataLabels: {enabled: false},
                                    stroke: {show: true,width: 2,colors: ['transparent']},
                                    xaxis: {
                                        categories: [
                                            "<?php echo e($OylikTulovAll[0]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[1]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[2]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[3]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[4]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[5]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[6]['date']); ?>"
                                        ],
                                    },
                                    yaxis: {title: {text: "Oylik to'lovlar"}},
                                fill: {opacity: 1},
                                tooltip: {y: {formatter: function(val) {return val + " so'm"}}}
                                }).render();
                            });
                        </script>
                        <div class="table-responsive">
                            <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                                <thead>
                                    <tr>
                                        <th>#/#</th>
                                        <th><?php echo e($OylikTulovAll[0]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[1]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[2]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[3]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[4]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[5]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[6]['date']); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th style="text-align:left;">Naqt To'lovlar</th>
                                        <td><?php echo e($OylikTulovAll[0]['Naqt_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Naqt_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Naqt_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Naqt_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Naqt_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Naqt_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Naqt_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;">Plastik To'lovlar</th>
                                        <td><?php echo e($OylikTulovAll[0]['Plastik_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Plastik_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Plastik_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Plastik_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Plastik_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Plastik_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Plastik_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;">Payme to'lov</th>
                                        <td><?php echo e($OylikTulovAll[0]['Payme_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Payme_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Payme_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Payme_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Payme_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Payme_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Payme_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;">Chegirma To'lovlar</th>
                                        <td><?php echo e($OylikTulovAll[0]['Chegirma_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Chegirma_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Chegirma_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Chegirma_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Chegirma_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Chegirma_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Chegirma_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;">Qaytarilgan To'lovlar</th>
                                        <td><?php echo e($OylikTulovAll[0]['Qaytar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Qaytar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Qaytar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Qaytar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Qaytar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Qaytar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Qaytar_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;">Naqt + Plastik + Payme - Qaytarildi</th>
                                        <td><?php echo e($OylikTulovAll[0]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['TulovSum_table']); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-12">
                        <h1 class="card-title">To'lov Statistikasi</h1>
                        <canvas id="barChart" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                                new Chart(document.querySelector('#barChart'), {
                                    type: 'bar',
                                    data: {
                                        labels: [
                                            "<?php echo e($OylikTulovAll[0]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[1]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[2]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[3]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[4]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[5]['date']); ?>",
                                            "<?php echo e($OylikTulovAll[6]['date']); ?>"
                                        ],
                                        datasets: [{
                                            label: "To'lovlar",
                                            data: [
                                                <?php echo e($OylikTulovAll[0]['Tulovlar']); ?>,
                                                <?php echo e($OylikTulovAll[1]['Tulovlar']); ?>,
                                                <?php echo e($OylikTulovAll[2]['Tulovlar']); ?>,
                                                <?php echo e($OylikTulovAll[3]['Tulovlar']); ?>,
                                                <?php echo e($OylikTulovAll[4]['Tulovlar']); ?>,
                                                <?php echo e($OylikTulovAll[5]['Tulovlar']); ?>,
                                                <?php echo e($OylikTulovAll[6]['Tulovlar']); ?>

                                            ],
                                            backgroundColor: ['rgba(39, 208, 255, 0.2)'],
                                            borderColor: ['rgb(39, 208, 255)'],
                                            borderWidth: 1
                                        },{label: "Xarajatlar",
                                            data: [
                                                <?php echo e($OylikTulovAll[0]['Xarajatlar']); ?>,
                                                <?php echo e($OylikTulovAll[1]['Xarajatlar']); ?>,
                                                <?php echo e($OylikTulovAll[2]['Xarajatlar']); ?>,
                                                <?php echo e($OylikTulovAll[3]['Xarajatlar']); ?>,
                                                <?php echo e($OylikTulovAll[4]['Xarajatlar']); ?>,
                                                <?php echo e($OylikTulovAll[5]['Xarajatlar']); ?>,
                                                <?php echo e($OylikTulovAll[6]['Xarajatlar']); ?>

                                            ],
                                            backgroundColor: ['rgba(69, 96, 255, 0.2)'],
                                            borderColor: ['rgb(69, 96, 255)'],
                                            borderWidth: 1
                                        },{label: "Ish haqi",
                                            data: [
                                                <?php echo e($OylikTulovAll[0]['IshHaq']); ?>,
                                                <?php echo e($OylikTulovAll[1]['IshHaq']); ?>,
                                                <?php echo e($OylikTulovAll[2]['IshHaq']); ?>,
                                                <?php echo e($OylikTulovAll[3]['IshHaq']); ?>,
                                                <?php echo e($OylikTulovAll[4]['IshHaq']); ?>,
                                                <?php echo e($OylikTulovAll[5]['IshHaq']); ?>,
                                                <?php echo e($OylikTulovAll[6]['IshHaq']); ?>

                                            ],
                                            backgroundColor: ['rgba(175, 25, 255, 0.2)'],
                                            borderColor: ['rgb(175, 25, 255)'],
                                            borderWidth: 1
                                        },{label: "Daromad",
                                            data: [
                                                <?php echo e($OylikTulovAll[0]['Daromat']); ?>,
                                                <?php echo e($OylikTulovAll[1]['Daromat']); ?>,
                                                <?php echo e($OylikTulovAll[2]['Daromat']); ?>,
                                                <?php echo e($OylikTulovAll[3]['Daromat']); ?>,
                                                <?php echo e($OylikTulovAll[4]['Daromat']); ?>,
                                                <?php echo e($OylikTulovAll[5]['Daromat']); ?>,
                                                <?php echo e($OylikTulovAll[6]['Daromat']); ?>

                                            ],
                                            backgroundColor: ['rgba(255, 25, 255, 0.2)'],
                                            borderColor: ['rgb(255, 25, 255)'],
                                            borderWidth: 1
                                        }]
                                    },
                                    options: {scales: {y: {beginAtZero: true}}}
                                });
                            });
                        </script>
                        <div class="table-responsive">
                            <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                                <thead>
                                    <tr>
                                        <th>#/#</th>
                                        <th><?php echo e($OylikTulovAll[0]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[1]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[2]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[3]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[4]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[5]['date']); ?></th>
                                        <th><?php echo e($OylikTulovAll[6]['date']); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th style="text-align:left;"><b title="Naqt+Plastik+Payme-Qaytarildi">To'lovlar</b></th>
                                        <td><?php echo e($OylikTulovAll[0]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['TulovSum_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['TulovSum_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;"><b title="Umumit xarajatlar">Xarajatlar</b></th>
                                        <td><?php echo e($OylikTulovAll[0]['Xarajatlar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Xarajatlar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Xarajatlar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Xarajatlar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Xarajatlar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Xarajatlar_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Xarajatlar_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;"><b title="Hodim+O'qituvchi">Ish haqi</b></th>
                                        <td><?php echo e($OylikTulovAll[0]['IshHaq_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['IshHaq_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['IshHaq_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['IshHaq_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['IshHaq_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['IshHaq_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['IshHaq_table']); ?></td>
                                    </tr>
                                    <tr>
                                        <th style="text-align:left;"><b title="Daromad">Daromad</b></th>
                                        <td><?php echo e($OylikTulovAll[0]['Daromat_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[1]['Daromat_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[2]['Daromat_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[3]['Daromat_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[4]['Daromat_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[5]['Daromat_table']); ?></td>
                                        <td><?php echo e($OylikTulovAll[6]['Daromat_table']); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyCrm_ATKO\resources\views/SuperAdmin/statistik/index.blade.php ENDPATH**/ ?>