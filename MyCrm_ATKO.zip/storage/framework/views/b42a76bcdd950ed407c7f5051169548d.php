<?php $__env->startSection('title',"Guruhlarim"); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Guruhlarim</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('User')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Guruhlarim</li>
            </ol>
        </nav>
    </div>
    <section class="section dashboard">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $Guruhlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4">
                <a href="<?php echo e(route('GuruhShow',$item['id'] )); ?>">
                    <div class="card">
                        <img src="<?php echo e($item['image']); ?>" 
                        class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title w-100 text-center my-0 py-1"><?php echo e($item['name']); ?></h5>
                            <div class="row text-center">
                                <div class="col-6">
                                    <p class="p-0 m-0">Boshlanish vaqt</p>
                                    <?php echo e($item['start']); ?>

                                </div>
                                <div class="col-6">
                                    <p class="p-0 m-0">Tugash vaqt</p>
                                    <?php echo e($item['end']); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-lg-12 text-center">
                <div class="card">
                    <div class="card-body"><p class="card-title">Sizda guruhlar mavjud emas.</p></div>
                </div>
                
            </div>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyCrm_ATKO\resources\views/User/guruh.blade.php ENDPATH**/ ?>