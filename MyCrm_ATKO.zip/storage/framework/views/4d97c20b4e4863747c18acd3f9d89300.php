
<?php $__env->startSection('title','Online Kurslar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Online Kurslar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Online Kurslar</li>
            <li class="breadcrumb-item active">Taxrirlash</li>
        </ol>
    </nav>
</div> 
    <section class="section dashboard">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <h1 class="card-title">Online kursni taxrirlash</h1>
                <form action="<?php echo e(route('online_update',$Cours->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6 my-2">
                            <label for="">Kursning nomi</label>
                            <input type="text" class="form-control" disabled value="<?php echo e($Cours->cours_name); ?>">
                            <input type="hidden" name="cours_id" value="<?php echo e($Cours->id); ?>">
                        </div>
                        <div class="col-lg-6 my-2">
                            <label for="cours_id_api">Online kursni tanlang</label>
                            <select name="cours_id_api" class="form-select" required>
                                <option value="">Tanlang...</option>
                                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->cours_id); ?>"><?php echo e($value->cours_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-12 my-2">
                            <button class="btn btn-primary" type="submit">Saqlash</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyCrm_ATKO\resources\views/SuperAdmin/online/update.blade.php ENDPATH**/ ?>