<?php $__env->startSection('title','Talabalar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Talabalar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Talabalar</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>

        <section class="section dashboard">
            <div class="card">
                <div class="card-body pt-3">
                    <ul class="nav nav-tabs d-flex" id="myTabjustified" role="tablist">
                        <li class="nav-item flex-fill" role="presentation">
                            <a href="<?php echo e(route('Student')); ?>" class="nav-link text-center text-center bg-success text-white w-100 active">Tashriflar</a>
                        </li>
                        <li class="nav-item flex-fill" role="presentation">
                            <a href="<?php echo e(route('StudentQarzdorlar')); ?>" class="nav-link w-100 text-center">Qarzdorlar</a>
                        </li>
                        <li class="nav-item flex-fill" role="presentation">
                            <a href="<?php echo e(route('StudentTulovlar')); ?>" class="nav-link text-center w-100">To'lovlar</a>
                        </li>
                        <li class="nav-item flex-fill" role="presentation">
                            <a href="<?php echo e(route('StudentCreate')); ?>" class="nav-link text-center w-100">Yangi tashrif</a>
                        </li>
                    </ul>
                    <div class="tab-content pt-2" id="myTabjustifiedContent">
                        <div class="tab-pane fade show active" style="min-height:300px;" id="home-justified" role="tabpanel" aria-labelledby="home-tab">
                            <div class="table-responsive">
                                <table class="table datatable" style="font-size:14px;">
                                    <thead>
                                        <tr>
                                            <th class="bg-primary text-white text-center">#</th>
                                            <th class="bg-primary text-white text-center">FIO</th>
                                            <th class="bg-primary text-white text-center">Manzil</th>
                                            <th class="bg-primary text-white text-center">Telefon raqam</th>
                                            <th class="bg-primary text-white text-center">Guruhlar</th>
                                            <th class="bg-primary text-white text-center">Ro'yhatdan o'tdi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                            <th>
                                                <a href="<?php echo e(route('StudentShow',$item['id'])); ?>">
                                                    <?php echo e($item['name']); ?>

                                                </a>
                                            </th>
                                            <td><?php echo e($item['addres']); ?></td>
                                            <td class="text-center"><?php echo e($item['phone']); ?></td>
                                            <td class="text-center"><?php echo e($item['created_at']); ?></td>
                                            <td class="text-center"><?php echo e($item['guruhlar']); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan=6 class="text-center">Tashriflar mavjud emas.</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
          
                    
        </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyCrm_ATKO\resources\views/Admin/user/index.blade.php ENDPATH**/ ?>