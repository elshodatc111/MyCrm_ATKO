<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\CreateTashrif' => 
    array (
      0 => 'App\\Listeners\\CreateTashrifAdminKassa@handle',
      1 => 'App\\Listeners\\CreateTashrifSendMessege@handle',
    ),
    'App\\Events\\debitSendMessege' => 
    array (
      0 => 'App\\Listeners\\DeberSendMessege@handle',
    ),
    'App\\Events\\CreatIshHaqi' => 
    array (
      0 => 'App\\Listeners\\IshHaqiFililaKassaUpdate@handle',
    ),
    'App\\Events\\CreateHodim' => 
    array (
      0 => 'App\\Listeners\\NewHodimCreateKassa@handle',
      1 => 'App\\Listeners\\NewHodimSendMessege@handle',
    ),
    'App\\Events\\Payme' => 
    array (
      0 => 'App\\Listeners\\PaymeChegirma@handle',
    ),
    'App\\Events\\AdminCreateTecher' => 
    array (
      0 => 'App\\Listeners\\SendMessegeCreatTecher@handle',
    ),
    'App\\Events\\HodimUpdatePasswor' => 
    array (
      0 => 'App\\Listeners\\SendMessegeHodimUpdatePassword@handle',
    ),
    'App\\Events\\TugilganKun' => 
    array (
      0 => 'App\\Listeners\\SendMessegeTkun@handle',
    ),
    'App\\Events\\UserResetPassword' => 
    array (
      0 => 'App\\Listeners\\UserPassUpdateSendMessege@handle',
    ),
    'App\\Events\\createTulov' => 
    array (
      0 => 'App\\Listeners\\UserTulov@handle',
    ),
  ),
);