<?php $__env->startSection('title','Tug\'ilgan kunlar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Tug'ilgan kunlar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Tug'ilgan kunlar</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title w-100 text-center">Bugun talabalarning tug'ilgan kuni</h5>
            <div class="table-responsive">
                <p class="p-0 m-0 text-danger w-100 text-center">Bugun tug'ilgan kunlarni nishonlayatgan talabalarga soat 10:00 da sms tabrik yuboriladi.</p>
                <table class="table text-center table-bordered">
                    <thead>
                        <tr>
                            <th class="bg-primary text-white">#</th>
                            <th class="bg-primary text-white">FIO</th>
                            <th class="bg-primary text-white">Telefon raqam</th>
                            <th class="bg-primary text-white">Tug'ilgan kun</th>
                            <th class="bg-primary text-white">Manzil</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tkun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->index+1); ?></td>
                            <td style="text-align:left"><a href="<?php echo e(route('StudentShow',$item['id'])); ?>"><?php echo e($item['name']); ?></a></td>
                            <td><?php echo e($item['phone']); ?></td>
                            <td><?php echo e($item['tkun']); ?></td>
                            <td><?php echo e($item['addres']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center" colspan="5">Bugun tug'ilgan kunlar yo'q.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\Admin\messege\tkun.blade.php ENDPATH**/ ?>