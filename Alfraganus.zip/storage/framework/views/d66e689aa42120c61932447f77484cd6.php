<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Bosh sahifa</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('User')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Balansni to'ldirish</li>
            </ol>
        </nav>
    </div>
        <div class="dashboard">
            <div class="col-12">
                <h4 class="card-title">To'lov turini tanlang</h4>
                <p><b>Tulov summasi: </b><?php echo e($summa); ?> so'm</p>
                <form method="POST" action="https://checkout.paycom.uz">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="merchant" value="65f14418a929127d44bcb5d1"/>
                    <input type="hidden" name="amount" value="<?php echo e($summa2); ?>"/>
                    <input type="hidden" name="account[onwer_id]" value="<?php echo e(Auth::user()->id); ?>"/>
                    <input type="hidden" name="lang" value="uz"/>
                    <input type="hidden" name="callback_timeout" value="15"/>
                    <button type="submit" class="btn btn-primary p-5 py-3"> <b>Payme</b> </button>
                </form>
            </div>
        </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\User\pay.blade.php ENDPATH**/ ?>