<?php $__env->startSection('title','Kabinet'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Kabinet</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Kabinet</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title w-100 text-center mb-0"><?php echo e(Auth::User()->name); ?></h5>
                <form action="<?php echo e(route('adminkabinetupdate')); ?>" method="POST">
                    <?php echo csrf_field(); ?> 
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="name" class="form-label pt-0 mt-2 mb-1 pb-0">FIO</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(Auth::User()->name); ?>" required>
                            <label for="phone" class="form-label pt-0 mt-2 mb-1 pb-0">Telefon raqam</label>
                            <input type="text" class="form-control phone" value="<?php echo e(Auth::User()->phone); ?>" name="phone" required>
                            <label for="phone2" class="form-label pt-0 mt-2 mb-1 pb-0">Ikkinchi telefon raqam</label>
                            <input type="text" class="form-control phone" value="<?php echo e(Auth::User()->phone2); ?>" name="phone2" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="addres" class="form-label pt-0 mt-2 mb-1 pb-0">Yashash manzili</label>
                            <input type="text" class="form-control" name="addres" disabled value="<?php echo e(Auth::User()->addres); ?>" required>
                            <label for="tkun" class="form-label pt-0 mt-2 mb-1 pb-0">Tug'ilgan kun</label>
                            <input type="text" class="form-control" name="tkun" disabled value="<?php echo e(Auth::User()->tkun); ?>" required>
                            <label for="email" class="form-label pt-0 mt-2 mb-1 pb-0">Login</label>
                            <input type="text" class="form-control" name="email" disabled value="<?php echo e(Auth::User()->email); ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3 w-100">O'zgarishlarni saqlash</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title w-100 text-center mb-0">Parolni yangilash</h5>
                <form action="<?php echo e(route('adminkabinetpasswupdate')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <label for="password" class="form-label pt-0 mt-2 mb-1 pb-0">Joriy parol (min:8)</label>
                    <input type="password" class="form-control" name="password" required>
                    <label for="newpassword" class="form-label pt-0 mt-2 mb-1 pb-0">Yangi parol (min:8)</label>
                    <input type="password" class="form-control" name="newpassword" required>
                    <label for="nextpassword" class="form-label pt-0 mt-2 mb-1 pb-0">Yangi parolni takrorlang (min:8)</label>
                    <input type="password" class="form-control" name="nextpassword" required>
                    <button type="submit" class="btn btn-primary mt-3 w-100">Parolni yangilash</button>
                </form>
            </div>
        </div>
    </div>
</div>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\Admin\profel.blade.php ENDPATH**/ ?>