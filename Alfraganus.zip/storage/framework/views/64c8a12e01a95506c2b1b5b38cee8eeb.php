<?php $__env->startSection('title','Murojatlar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Murojatlar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Murojatlar</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>

  <section class="section dashboard">
    <div class="card">
      <div class="card-body row pt-4">
        <div class="col-4">
            <div class="list-group border" style="height:400px;overflow-x: hidden;overflow-y: scroll">
                <?php $__currentLoopData = $Murojatlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('AdminMurojarlarShow', $item['user_id'])); ?>" class="list-group-item list-group-item-action" aria-current="true">
                    <div class="d-flex p-0 w-100 justify-content-between">
                        <h6 class="p-0 m-0"><?php echo e($item['name']); ?></h6>
                        <small class="text-muted" style="font-size:8px;padding-top:7px;"><?php echo e($item['created_at']); ?></small>
                    </div>  
                    <?php if($item['admin_type']==true): ?> 
                        <p class="p-0 m-0 d-none d-lg-block text-primary"><?php echo e($item['text']); ?></p>  
                    <?php else: ?>
                        <p class="p-0 m-0 d-none d-lg-block text-muted"><?php echo e($item['text']); ?></p>    
                    <?php endif; ?>                    
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
      </div>
    </div>   
  </section>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\Admin\messege\murojat.blade.php ENDPATH**/ ?>