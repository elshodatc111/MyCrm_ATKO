
<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
      <h1>Bosh sahifa</h1>
      <nav>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
              <li class="breadcrumb-item active">Kunlik to'lovlar</li>
          </ol>
      </nav>
  </div>


    <section class="section dashboard">
        <div class="card">
            <div class="card-body">
                <h1 class="card-title e-100 text-center">Kunlik to'lovlar(<?php echo e($data); ?>)</h1>
                <div class="table-responsive">
                    <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Filial</th>
                                <th>Talaba</th>
                                <th>Summa</th>
                                <th>Tulov turi</th>
                                <th>Tulov haqida</th>
                                <th>Meneger</th>
                                <th>Tulov vaqti</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Tulovlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['Filial']); ?></td>
                                <td><?php echo e($item['User']); ?></td>
                                <td><?php echo e($item['Summa']); ?></td>
                                <td><?php echo e($item['Type']); ?></td>
                                <td><?php echo e($item['About']); ?></td>
                                <td><?php echo e($item['Admin']); ?></td>
                                <td><?php echo e($item['created_at']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>  
    </section>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\SuperAdmin\statistik\kunlik_tulov.blade.php ENDPATH**/ ?>