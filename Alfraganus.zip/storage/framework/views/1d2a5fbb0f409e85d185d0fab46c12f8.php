<?php $__env->startSection('title','Xarajatlar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Hisobot</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('hisobot')); ?>">Hisobot</a></li>
                <li class="breadcrumb-item active">Xarajatlar</li>
            </ol>
        </nav>
    </div> 

    
    <h5 class="w-100 text-center">Xarajatlar</h5>
    <div class="w-100" style="text-align:right">
        <a id='export' style='cursor:pointer' class="btn btn-warning text-white"> EXCEL</a>
    </div>
    <table class="table table-bordered mt-3" style="font-size:10px" id="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Filial</th>
                <th>Xarajat status</th>
                <th>Summasi</th>
                <th>Xarajat turi</th>
                <th>Xarajat haqida</th>
                <th>Meneger</th>
                <th>Admin</th>
                <th>Xarajat vaqti</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $CHiqim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($item['filial']); ?></td>
                    <td><?php echo e($item['xodisa']); ?></td>
                    <td><?php echo e($item['summa']); ?></td>
                    <td><?php echo e($item['type']); ?></td>
                    <td><?php echo e($item['about']); ?></td>
                    <td><?php echo e($item['user_id']); ?></td>
                    <td><?php echo e($item['admin_id']); ?></td>
                    <td><?php echo e($item['created_at']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
                    

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\SuperAdmin\hisobot\xarajat.blade.php ENDPATH**/ ?>