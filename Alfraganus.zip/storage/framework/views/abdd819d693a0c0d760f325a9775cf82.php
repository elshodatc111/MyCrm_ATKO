<?php $__env->startSection('title',"Guruh"); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Guruh</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('User')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('Guruhlar')); ?>">Guruhlarim</a></li>
                <li class="breadcrumb-item active">Guruh</li>
            </ol>
        </nav>
    </div> 
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-4"> 
                <div class="card">
                    <img src="https://atko.tech/NiceAdmin/assets/img/cours.jpg" class="card-img-top">
                    <div class="card-body p-0">
                        <ul class="list-group" style="border-radius:0">
                            <h5 class="card-title w-100 text-center py-2 mb-0"><?php echo e($Guruhs['guruh_name']); ?></h5>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Kurs narxi:<span class="badge bg-primary rounded-pill"><?php echo e($Guruhs['guruh_price']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Dars vaqti:<span class="badge bg-primary rounded-pill"><?php echo e($Guruhs['guruh_vaqt']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                O'qituvchi:<span class="badge bg-primary rounded-pill"><?php echo e($Guruhs['techer']); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-0">Dars kunlari</h5>
                        <?php if($CountDates==13): ?>
                            <table class="table table-bordered">
                                <tr>
                                    <td><?php echo e($GuruhTime[0]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[6]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[1]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[7]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[2]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[8]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[3]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[9]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[4]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[10]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[5]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[11]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td colspan=2><?php echo e($GuruhTime[12]['dates']); ?></td>
                                </tr>
                            </table>
                        <?php elseif($CountDates==24): ?>
                            <table class="table table-bordered" style="font-size:14px">
                                <tr>
                                    <td><?php echo e($GuruhTime[0]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[8]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[16]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[1]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[9]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[17]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[2]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[10]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[18]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[3]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[11]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[19]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[4]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[12]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[20]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[5]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[13]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[21]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[6]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[14]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[22]['dates']); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e($GuruhTime[7]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[15]['dates']); ?></td>
                                    <td><?php echo e($GuruhTime[23]['dates']); ?></td>
                                </tr>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php elseif(Session::has('error')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
            <?php endif; ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">Test Natijalari</h5>
                        <?php if($Tests=='true'): ?>
                            <a href="<?php echo e(route('GuruhShowTest',$id)); ?>" class="btn btn-success">Testni boshlash</a>
                        <?php elseif($Tests=='Natija'): ?>
                            <table class="table table-bordered text-center">
                                <tr>
                                    <th>Testlar Soni</th>
                                    <th>To'gri javob</th>
                                    <th>Noto'g'ri javob</th>
                                    <th>Ball</th>
                                    <th>Test vaqti</th>
                                </tr>
                                <tr>
                                    <td><?php echo e($Natija['savol_count']); ?></td>
                                    <td><?php echo e($Natija['tugri_count']); ?></td>
                                    <td><?php echo e($Natija['notugri_count']); ?></td>
                                    <td><?php echo e($Natija['ball']); ?></td>
                                    <td><?php echo e($Natija['created_at']); ?></td>
                                </tr>
                            </table>
                        <?php else: ?>
                            <p class="text-danger"><?php echo e($Tests); ?> testni kundan boshlab yechish mumkun.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
          
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\User\guruh_show.blade.php ENDPATH**/ ?>