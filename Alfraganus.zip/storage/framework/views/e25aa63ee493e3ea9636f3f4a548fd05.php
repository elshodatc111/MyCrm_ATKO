<?php $__env->startSection('title','Hisobot'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Hisobot</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('hisobot')); ?>">Hisobot</a></li>
                <li class="breadcrumb-item active">Test natijalari</li>
            </ol>
        </nav>
    </div> 

    
    <h5 class="w-100 text-center">Test natijalari</h5>
    <div class="w-100" style="text-align:right">
        <a id='export' style='cursor:pointer' class="btn btn-warning text-white"> EXCEL</a>
    </div>
    <table class="table table-bordered mt-3" style="font-size:10px" id="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Filial</th>
                <th>Guruh</th>
                <th>Talaba</th>
                <th>Savollar soni</th>
                <th>To'g'ri javob</th>
                <th>Noto'g'ri javob</th>
                <th>Ball</th>
                <th>To'lov vaqti</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $Test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($item['filial']); ?></td>
                    <td><?php echo e($item['guruh']); ?></td>
                    <td><?php echo e($item['user']); ?></td>
                    <td><?php echo e($item['savollar']); ?></td>
                    <td><?php echo e($item['tugri_count']); ?></td>
                    <td><?php echo e($item['notugri_count']); ?></td>
                    <td><?php echo e($item['ball']); ?></td>
                    <td><?php echo e($item['created_at']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
                    

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\SuperAdmin\hisobot\test_natija.blade.php ENDPATH**/ ?>