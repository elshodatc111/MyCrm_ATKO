<?php $__env->startSection('title','Settings'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Settings</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item active">Settings</li>
            </ol>
        </nav>
    </div>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    <?php elseif(Session::has('error')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    <?php endif; ?>

    <section class="section dashboard">
        <div class="card">
            <div class="card-body mt-3">
                <div class="row ">
                    <div class="col-lg-4">
                            <form action="<?php echo e(route('settingupdate')); ?>" method="post">
                                <?php echo csrf_field(); ?> 
                                <label for="EndData" class="mt-2 mb-2" style="font-weight:700">Filial bloklanish muddati</label>
                                <input type="date" name="EndData" value="<?php echo e($Setting['EndData']); ?>" class="form-control mb-2" required>
                                <label for="Summa" class="mt-2 mb-2" style="font-weight:700">Tulov summasi</label>
                                <input type="number" name="Summa" value="<?php echo e($Setting['Summa']); ?>" class="form-control mb-2" required>
                                <label for="Username" class="mt-2 mb-2" style="font-weight:700">Username</label>
                                <input type="text" name="Username" value="<?php echo e($Setting['Username']); ?>" class="form-control mb-2" required>
                                <label for="Status" class="mt-2 mb-2" style="font-weight:700">Filial xolati</label>
                                <div class="form-check form-switch">
                                    <?php if($Setting['Status']=='true'): ?>
                                        <input class="form-check-input" type="checkbox" name="Status" checked>
                                    <?php else: ?>
                                        <input class="form-check-input" type="checkbox" name="Status">
                                    <?php endif; ?>
                                </div>
                                <button  type="submit" class="btn btn-primary w-100 mt-3">O'zgarishlarni saqlash</button>
                            </form>
                        </div>
                        <div class="col-lg-4 text-center">
                            <h5 class="card-title">Markazga SMS limit kiritish</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Yuborilgan</th>
                                        <th>Mavjud SMS</th>
                                    </tr>
                                    <tr>
                                        <td><?php echo e($SmsCounter['counte']); ?></td>
                                        <td><?php echo e($SmsCounter['maxsms']); ?></td>
                                    </tr>
                                </thead>
                            </table>
                            <form action="<?php echo e(route('settingsmsplus')); ?>" method="post">
                                <?php echo csrf_field(); ?> 
                                <label for="sms">SMS qo'shish</label>
                                <input type="number" name="sms" class="form-control mt-2" required>
                                <button type="submit" class="btn btn-primary mt-2 w-100">SMS qo'shish</button>
                            </form>
                        </div>
                    </div>
            </div>
        </div>
        
                
    </section>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views/setting.blade.php ENDPATH**/ ?>