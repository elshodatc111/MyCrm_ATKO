<?php $__env->startSection('title',"Guruh"); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Guruh</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('User')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('Guruhlar')); ?>">Guruhlarim</a></li>
                <li class="breadcrumb-item active">Guruh</li>
            </ol>
        </nav>
    </div> 
    <section class="section dashboard"> 
        <form action="<?php echo e(route('GuruhShowTestCheck')); ?>" method="post">
            <?php echo csrf_field(); ?> 
            <input type="hidden" name="guruh_id" value="<?php echo e($guruh_id); ?>">
            <input type="hidden" name="TestCount" value="<?php echo e($TestCount); ?>">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $Testlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item['Savol']); ?></h5>
                            <?php switch($key%4):
                                case (0): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="D11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="D11<?php echo e($key); ?>"><?php echo e($item['NJavob1']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="C11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="C11<?php echo e($key); ?>"><?php echo e($item['NJavob2']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="B22<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="B22<?php echo e($key); ?>"><?php echo e($item['NJavob3']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="A11<?php echo e($key); ?>" value="true" required>
                                        <label class="form-check-label" for="A11<?php echo e($key); ?>"><?php echo e($item['TJavob']); ?></label>
                                    </div>
                                    <?php break; ?>
                                <?php case (1): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="D11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="D11<?php echo e($key); ?>"><?php echo e($item['NJavob1']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="A11<?php echo e($key); ?>" value="true" required>
                                        <label class="form-check-label" for="A11<?php echo e($key); ?>"><?php echo e($item['TJavob']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="C11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="C11<?php echo e($key); ?>"><?php echo e($item['NJavob2']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="B22<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="B22<?php echo e($key); ?>"><?php echo e($item['NJavob3']); ?></label>
                                    </div>
                                    <?php break; ?>
                                <?php case (2): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="D11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="D11<?php echo e($key); ?>"><?php echo e($item['NJavob1']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="C11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="C11<?php echo e($key); ?>"><?php echo e($item['NJavob2']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="B22<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="B22<?php echo e($key); ?>"><?php echo e($item['NJavob3']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="A11<?php echo e($key); ?>" value="true" required>
                                        <label class="form-check-label" for="A11<?php echo e($key); ?>"><?php echo e($item['TJavob']); ?></label>
                                    </div>
                                    <?php break; ?>
                                <?php case (3): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="A11<?php echo e($key); ?>" value="true" required>
                                        <label class="form-check-label" for="A11<?php echo e($key); ?>"><?php echo e($item['TJavob']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="D11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="D11<?php echo e($key); ?>"><?php echo e($item['NJavob1']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="C11<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="C11<?php echo e($key); ?>"><?php echo e($item['NJavob2']); ?></label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="test_id<?php echo e($key); ?>" id="B22<?php echo e($key); ?>" value="false" required>
                                        <label class="form-check-label" for="B22<?php echo e($key); ?>"><?php echo e($item['NJavob3']); ?></label>
                                    </div>
                                    <?php break; ?>
                            <?php endswitch; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body"><h5 class="card-title">Testlar mavjud emas.</h5></div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($TestCount!=0): ?>
                <div class="col-lg-12 text-center">
                    <button type="submit" class="btn btn-primary w-50">Tekshirish</button>
                </div>
                <?php endif; ?>
            </div>
        </form>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\User\test_show.blade.php ENDPATH**/ ?>