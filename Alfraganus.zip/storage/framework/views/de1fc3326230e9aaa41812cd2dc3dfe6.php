<?php $__env->startSection('title','Guruhlar'); ?>
<?php $__env->startSection('content'); ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruhlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('Techer')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Guruhlar</li>
                </ol>
            </nav>
        </div>
    
        <section class="section dashboard">
            <div class="card info-card sales-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Sizning guruhlaringiz.</span></h5>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Guruh</th>
                                    <th>Boshlanish vaqti</th>
                                    <th>Tugash vaqti</th>
                                    <th>Talabalar</th>
                                    <th>Dars vaqti</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $Guruh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td style="text-align:left"><a href="<?php echo e(route('TGuruhShow',$item['id'])); ?>"><?php echo e($item['guruh_name']); ?></a></td>
                                    <td><?php echo e($item['guruh_start']); ?></td>
                                    <td><?php echo e($item['guruh_end']); ?></td>
                                    <td><?php echo e($item['users']); ?></td>
                                    <td><?php echo e($item['guruh_vaqt']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center">Guruhlar mavjud emas.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>  
        </section>

    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Techer.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\Techer\grops.blade.php ENDPATH**/ ?>