<?php $__env->startSection('title','Guruhlar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Guruhlar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Guruhlar</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<section class="section dashboard">
    <div class="card info-card sales-card">
        <div class="card-body text-center pt-3">
            <ul class="nav nav-tabs d-flex">
                <li class="nav-item flex-fill">
                    <a class="nav-link w-100 active bg-success text-white" href="<?php echo e(route('AdminGuruh')); ?>">Guruhlar</a>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <a class="nav-link w-100" href="<?php echo e(route('AdminGuruhEnd')); ?>">Yakunlangan guruhlar</a>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <a class="nav-link w-100" href="<?php echo e(route('AdminGuruhCreate')); ?>">Yangi guruh</a>
                </li>
            </ul>
            <div>
            <div class="table-responsive">
                <table class="table datatable text-center table-hover" style="font-size:14px;">
                    <thead>
                        <tr>
                            <th class="bg-primary text-white text-center">#</th>
                            <th class="bg-primary text-white text-center">Guruh</th>
                            <th class="bg-primary text-white text-center">Boshlanish vaqti</th>
                            <th class="bg-primary text-white text-center">Yakunlanish vaqti</th>
                            <th class="bg-primary text-white text-center">Talabalar</th>
                            <th class="bg-primary text-white text-center">Guruh holati</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $Guruhlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td style="text-align:left">
                            <a href="<?php echo e(route('AdminGuruhShow',$item['id'])); ?>">
                                <?php echo e($item['guruh_name']); ?>

                            </td>
                            <td><?php echo e($item['guruh_start']); ?></td>
                            <td><?php echo e($item['guruh_end']); ?></td>
                            <td><?php echo e($item['talabalar']); ?></td>
                            <td>
                                <?php if($item['guruh']==0): ?>
                                    <span class="bg-success text-white px-1" style="border-radius:5px">FAOL</span>                                
                                <?php elseif($item['guruh']==1): ?>
                                    <span class="bg-info text-white px-1" style="border-radius:5px">YANGI</span>
                                <?php else: ?>
                                    <span class="bg-danger text-white px-1" style="border-radius:5px">YAKUNLADNI</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan=6 class="text-center">Guruhlar mavjud emas.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views/Admin/guruh/index.blade.php ENDPATH**/ ?>