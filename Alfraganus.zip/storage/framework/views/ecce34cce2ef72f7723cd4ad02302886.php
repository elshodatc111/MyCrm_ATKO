
<?php $__env->startSection('title','Yuborilgan SMSlar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Statistika</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('sms')); ?>">SMS</a></li>
            <li class="breadcrumb-item active">Yuborilgan SMSlar</li>
        </ol>
    </nav>
</div> 
    <section class="section dashboard">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title w-100 text-center">Yuborilgan SMS(<?php echo e($start); ?>-<?php echo e($end); ?>)</h4>
                <table class="table table-bordered" style="font-size:12px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Telefon raqam</th>
                            <th>SMS matni</th>
                            <th>Yuborilgan vaqt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $SendMessege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td style="font-size:12px;"><?php echo e($item['phone']); ?></td>
                            <td style="text-align:left;font-size:12px;"><?php echo e($item['text']); ?></td>
                            <td style="font-size:10px;"><?php echo e($item['created_at']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views/SuperAdmin/sms/show.blade.php ENDPATH**/ ?>