<?php $__env->startSection('title','Guruhlar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Hisobot</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('hisobot')); ?>">Hisobot</a></li>
                <li class="breadcrumb-item active">Guruhlar</li>
            </ol>
        </nav>
    </div> 

    
    <h5 class="w-100 text-center">Guruhlar</h5>
    <div class="w-100" style="text-align:right">
        <a id='export' style='cursor:pointer' class="btn btn-warning text-white"> EXCEL</a>
    </div>
    <table class="table table-bordered mt-3" style="font-size:10px" id="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Filial</th>
                <th>Guruh</th>
                <th>O'qituvchi</th>
                <th>Kurs</th>
                <th>Xona</th>
                <th>Guruh Naqrxi</th>
                <th>Guruh Chegirma</th>
                <th>Admin Chegirma</th>
                <th>O'qituvchga tulov</th>
                <th>O'qituvchiga bonus</th>
                <th>Boshlanish vaqti</th>
                <th>Tugash vaqti</th>
                <th>Meneger</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $Guruh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index+1); ?></td>
                <td><?php echo e($item['filial']); ?></td>
                <td><?php echo e($item['guruh']); ?></td>
                <td><?php echo e($item['techer']); ?></td>
                <td><?php echo e($item['cours_name']); ?></td>
                <td><?php echo e($item['room_name']); ?></td>
                <td><?php echo e($item['guruh_price']); ?></td>
                <td><?php echo e($item['guruh_chegirma']); ?></td>
                <td><?php echo e($item['guruh_admin_chegirma']); ?></td>
                <td><?php echo e($item['techer_price']); ?></td>
                <td><?php echo e($item['techer_bonus']); ?></td>
                <td><?php echo e($item['guruh_start']); ?></td>
                <td><?php echo e($item['guruh_end']); ?></td>
                <td><?php echo e($item['meneger']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
                    

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\SuperAdmin\hisobot\guruhlar.blade.php ENDPATH**/ ?>