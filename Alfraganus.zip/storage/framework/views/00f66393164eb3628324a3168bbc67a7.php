<?php $__env->startSection('title','Eslatmalar'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Eslatmalar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Eslatmalar</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>

  <div class="card">
    <div class="card-body">
      <h5 class="card-title w-100 text-center">Eslatmalar</h5>
      <ul class="nav nav-tabs d-flex" id="myTabjustified" role="tablist">
        <li class="nav-item flex-fill" role="presentation">
          <button class="nav-link w-100 active" id="home-tab" 
          data-bs-toggle="tab" data-bs-target="#home-justified" 
          type="button" role="tab" aria-controls="home" 
          aria-selected="true">Aktiv Eslatmalar</button>
        </li>
        <li class="nav-item flex-fill" role="presentation">
          <button class="nav-link w-100" id="profile-tab" 
          data-bs-toggle="tab" data-bs-target="#profile-justified" 
          type="button" role="tab" aria-controls="profile" 
          aria-selected="false">Arxiv Eslatmalar</button>
        </li>
      </ul>
      <div class="tab-content pt-2" id="myTabjustifiedContent">
        <div class="tab-pane fade show active" id="home-justified" role="tabpanel" aria-labelledby="home-tab">
          <div class="table-responsive">
            <table class="table table-bordered text-center table-hover" style="font-size:12px;">
                <thead>
                  <tr>
                    <th class="text-center bg-primary text-white">#</th>
                    <th class="text-center bg-primary text-white">Student/Guruh</th>
                    <th class="text-center bg-primary text-white">Eslatma turi</th>
                    <th class="text-center bg-primary text-white">Eslatma matni</th>
                    <th class="text-center bg-primary text-white">Eslatma vaqti</th>
                    <th class="text-center bg-primary text-white">Meneger</th>
                    <th class="text-center bg-primary text-white">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $Eslatma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($loop->index+1); ?></td>
                      <td style="text-align:left;">
                        <a href="
                        <?php if($item['type']=='user'): ?>
                          <?php echo e(route('StudentShow',$item['user_guruh_id'])); ?>

                        <?php else: ?>
                          <?php echo e(route('AdminGuruhShow',$item['user_guruh_id'])); ?>

                        <?php endif; ?>
                        ">
                          <?php echo e($item['name']); ?>

                        </a>
                      </td>
                      <td><?php echo e($item['type']); ?></td>
                      <td style="text-align:left"><?php echo e($item['text']); ?></td>
                      <td><?php echo e($item['created_at']); ?></td>
                      <td><?php echo e($item['meneger']); ?></td>
                      <td>
                        <a href="<?php echo e(route('AdminEslatmaArxiv',$item['id'])); ?>" class="btn btn-primary px-1 py-0" title="Arxivlash"><i class="bi bi-archive"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan=7 class="text-center">Eslatmalar mavjud emas.</td>
                    </tr>
                  <?php endif; ?>
                </tbody>
            </table>
          </div>
        </div>
        <div class="tab-pane fade" id="profile-justified" role="tabpanel" aria-labelledby="profile-tab">
          <div class="table-responsive">
            <table class="table datatable text-center table-hover" style="font-size:12px;">
            <thead>
                  <tr>
                    <th class="text-center bg-primary text-white">#</th>
                    <th class="text-center bg-primary text-white">Student/Guruh</th>
                    <th class="text-center bg-primary text-white">Eslatma turi</th>
                    <th class="text-center bg-primary text-white">Eslatma matni</th>
                    <th class="text-center bg-primary text-white">Eslatma vaqti</th>
                    <th class="text-center bg-primary text-white">Meneger</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $Eslatma_arxiv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($loop->index+1); ?></td>
                      <td style="text-align:left;">
                        <a href="
                        <?php if($item['type']=='user'): ?>
                          <?php echo e(route('StudentShow',$item['user_guruh_id'])); ?>

                        <?php else: ?>
                          <?php echo e(route('AdminGuruhShow',$item['user_guruh_id'])); ?>

                        <?php endif; ?>
                        ">
                          <?php echo e($item['name']); ?>

                        </a>
                      </td>
                      <td><?php echo e($item['type']); ?></td>
                      <td style="text-align:left"><?php echo e($item['text']); ?></td>
                      <td><?php echo e($item['created_at']); ?></td>
                      <td><?php echo e($item['meneger']); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan=6 class="text-center">Arxiv eslatmalar mavjud emas.</td>
                    </tr>
                  <?php endif; ?>
                </tbody>
            </table>
          </div>
        </div>
      
        </div>
      </div><!-- End Default Tabs -->

    </div>
  </div>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alfraganus\resources\views\Admin\messege\eslatma.blade.php ENDPATH**/ ?>